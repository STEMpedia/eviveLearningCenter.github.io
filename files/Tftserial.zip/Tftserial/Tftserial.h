/*developed by Harsh Chittora for the evive platform.*/
//last editted : 07-07-2017


#ifndef tftserial
#define tftserial

#include<arduino.h>

#include "TFT_ST7735.h"


class tftSerial{
	public: 
		int i;  //integer to be printed
		char c; //character to be printed 
		String s;//string to be printed
	public:
		tftSerial(); //internally creates the class for lcd.
		void    begin();//innitialises the lcd


		//the print and println functions work same as the serial print and println
		void	print(int i);
		void    print(char c);
		void 	print(String s);
		void    println(char c);
		void	println(int i);
		void	println(String s);
		
	private:
		TFT_ST7735 tft;
		int next_line;//keep a track of the next line on tft.
		int next_col;//keep a track of the next column on tft.
		
	
		
};
int dig(int i);//count the no. of digits in the integer to keep correct track of column

#endif
