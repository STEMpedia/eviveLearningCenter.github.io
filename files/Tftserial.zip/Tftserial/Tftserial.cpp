#include "Tftserial.h"
	tftSerial :: tftSerial()
	{
		tft = TFT_ST7735();
	}
 
	void tftSerial :: begin()
	{
		tft.init();
		tft.setRotation(1);
		Serial.println(tft.width());
		Serial.println(tft.height());
		tft.fillScreen(ST7735_BLACK);
		next_line=0;
		next_col=0;
		tft.setCursor(next_line,next_col);
		tft.setTextColor(ST7735_WHITE);
		next_line=0;
	}

  void tftSerial :: print(int i)
  {
		tft.setCursor(next_col,next_line);
		tft.fillRect(next_col,next_line,8*dig(i)+8,8,ST7735_BLACK);
		//tft.print(">");
		tft.print(i);
		//next_line=next_line+8;
		next_col=next_col+8*dig(i);
		
		//Serial.println(dig(i));
		if(next_line>=112)
		  next_line=0;
		if(next_col>152)
		{
				next_col=0;
				next_line=next_line+16;
		}
  }

  void tftSerial :: print(char c)
  {
		tft.setCursor(next_col,next_line);
		tft.fillRect(next_col,next_line,24,8,ST7735_BLACK);
		//tft.print(">");
		tft.print(c);
		//next_line=next_line+8;
		next_col=next_col+8;
		
		if(next_line>=112)
		  next_line=0;
		if(next_col>152)
		{
			next_col=0;
			next_line=next_line+16;
		}
  }

   void tftSerial :: print(String s)
   {
		for(int j=0;j<s.length();j++)
		{
			tft.print(s[j]);
		}
   }
   
  void  tftSerial :: println(char c)
  {	
		
		next_line=next_line+16;
		tft.setCursor(0,next_line);
		tft.fillRect(0,next_line,tft.width(),24,ST7735_BLACK);
		tft.print(">");
		tft.print(c);
		
		next_col=next_col+8;
		if(next_line>=112)
			next_line=0;
		if(next_col>152)
		{
			next_col=0;
			next_line=next_line+16;
		}
  }
	
	
   void tftSerial :: println(int i)
   {
	   
		next_line=next_line+16;
		tft.setCursor(0,next_line);
		tft.fillRect(0,next_line,tft.width(),24,ST7735_BLACK);
		tft.print(">");
		tft.print(i);
		
		next_col=next_col+8*dig(i);
		if(next_line>120)
			next_line=0;
		if(next_col>152)
		{
			next_col=0;
			next_line=next_line+16;
		}
   }
   
   void tftSerial :: println(String s)
   {
	   next_line=next_line+16;
	   tft.fillRect(0,next_line,tft.width(),32*(1+s.length()/225),ST7735_BLACK);
	   next_col=0;
	   
	   print('>');
	   for(int j=0;j<s.length();j++)
		{
			print(s[j]);
		}
   }
	int  dig(int i)
	{
		if(i==0)
			return 1;
		
		int count=0;
			while(i != 0)
		{
			// n = n/10
			i /= 10;
			++count;
		}
		return count;
	}

